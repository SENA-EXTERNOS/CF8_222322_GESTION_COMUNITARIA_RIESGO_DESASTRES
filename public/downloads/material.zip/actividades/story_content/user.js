function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Gaiagb5HLV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

